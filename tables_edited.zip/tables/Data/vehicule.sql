
insert into vehicule values('1234ya54','citroen','xantia2.0','blanche',to_date('12-09-2014','DD-MM-YYYY'),35000,'c3','Nancy');

insert into vehicule values('7418yc54','citroen','saxo1.1','Noire',to_date('15-08-2014','DD-MM-YYYY'),23000,'c1','Nancy');

insert into vehicule values('5698yd54','peugeot','106xr1.1','Grise',to_date('15-09-2014','DD-MM-YYYY'),26000,'c1','Nancy');

insert into vehicule values('6213yd54','renault','twingo','Verte',to_date('20-09-2014','DD-MM-YYYY'),20350,'c1','Nancy');

insert into vehicule values('1789xv54','citroen','xsara1.4sx','Bleue',to_date('15-05-2013','DD-MM-YYYY'),98500,'c2','Nancy');

insert into vehicule values('2569yp54','peugeot','206hdi','Blanche',to_date('26-06-2014','DD-MM-YYYY'),12000,'c2','Nancy');

insert into vehicule values('5213ye54','renault','laguna1.8d','Noire',to_date('14-09-2014','DD-MM-YYYY'),62000,'c3','Nancy');

insert into vehicule values('4577yp54','peugeot','406sr2.0','Noire',to_date('15-03-2015','DD-MM-YYYY'),28000,'c3','Nancy');


insert into vehicule values('4588yp57','peugeot','406sr2.0','Noire',to_date('15-03-2015','DD-MM-YYYY'),28000,'c3','Metz');

insert into vehicule values('5522yp57','citroen','saxo1.1','Noire',to_date('15-03-2015','DD-MM-YYYY'),28000,'c1','Metz');

insert into vehicule values('3369yp57','peugeot','206hdi','Blanche',to_date('26-06-2014','DD-MM-YYYY'),12000,'c2','Metz');

