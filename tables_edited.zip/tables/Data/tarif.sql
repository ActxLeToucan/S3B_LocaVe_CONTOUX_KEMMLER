
insert into tarif values('t1',120.00,600.00,1.50,650.00,850.00,25.00);

insert into tarif values('t2',170.00,750.00,1.80,800.00,1100.00,30.00);

insert into tarif values('t3',210.00,900.00,2.10,1100.00,1500.00,40.00);

