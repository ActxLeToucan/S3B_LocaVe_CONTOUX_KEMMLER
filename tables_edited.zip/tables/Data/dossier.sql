
insert into dossier values(1,to_date('1-10-2015','DD-MM-YYYY'),to_date('5-10-2015','DD-MM-YYYY'),null,null,null,'t1','x',null,null,null,'duvig001','7418yc54','Nancy','Nancy','Nancy');

insert into dossier values(2,to_date('1-10-2015','DD-MM-YYYY'),to_date('5-10-2015','DD-MM-YYYY'),null,null,null,'t1',null,null,null,null,'dumon001','2569yp54','Nancy','Nancy','Nancy');

insert into dossier values(3,to_date('2-10-2015','DD-MM-YYYY'),to_date('10-10-2015','DD-MM-YYYY'),null,null,null,'t1','x',null,null,null,'delar001','1789xv54','Nancy','Nancy','Nancy');

insert into dossier values(4,to_date('2-10-2015','DD-MM-YYYY'),to_date('5-10-2015','DD-MM-YYYY'),null,null,null,'t1',null,null,null,null,'delam001','5213ye54','Nancy','Nancy','Nancy');

insert into dossier values(5,to_date('6-10-2015','DD-MM-YYYY'),to_date('7-10-2015','DD-MM-YYYY'),null,null,null,'t2','x',null,null,null,'roule001','7418yc54','Nancy','Nancy','Nancy');

insert into dossier values(6,to_date('10-10-2015','DD-MM-YYYY'),to_date('15-10-2015','DD-MM-YYYY'),null,null,null,'t1',null,null,null,null,'duvig001','6213yd54','Nancy','Strasbourg','Nancy');

insert into dossier values(7,to_date('10-10-2015','DD-MM-YYYY'),to_date('20-10-2015','DD-MM-YYYY'),null,null,null,'t1','x',null,null,null,'dumon001','1234ya54','Nancy','Nancy','Nancy');

insert into dossier values(8,to_date('13-10-2015','DD-MM-YYYY'),to_date('14-10-2015','DD-MM-YYYY'),null,null,null,'t3',null,null,null,null,'delar001','7418yc54','Nancy','Nancy','Nancy');

insert into dossier values(9,to_date('13-10-2015','DD-MM-YYYY'),to_date('14-10-2015','DD-MM-YYYY'),null,null,null,'t2',null,null,null,null,'delar001','6213yd54','Nancy','Nancy','Nancy');

insert into dossier values(10,to_date('21-10-2015','DD-MM-YYYY'),to_date('25-10-2015','DD-MM-YYYY'),null,null,null,'t1','x',null,null,null,'roule001','1234ya54','Nancy','Nancy','Nancy');