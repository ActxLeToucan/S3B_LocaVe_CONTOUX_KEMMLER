
insert into agence values('Nancy','Louvois Marc','0383911234','10, rue de la gare','Nancy','54000','France');

insert into agence values('Metz','Loubard Jean','0387231111','25, avenue gambetta','Metz', '57000','France');

insert into agence values('Strasbourg','Meyer Paul','0329211111','8, rue des tanneurs','Strasbourg','67000','France');