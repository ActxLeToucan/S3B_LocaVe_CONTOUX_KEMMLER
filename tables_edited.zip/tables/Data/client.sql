
insert into client values('duvig001','duvigne gérard','16, rue des vignerons','laxou','54100');

insert into client values('dumon001','dumont nathalie','78, avenue du maine','nancy','54000');

insert into client values('delar001','delaroche claude','2, rue des tilleuls','vandoeuvre','54500');

insert into client values('delam001','delamontagne eric','5, rue des acacias','nancy','54000');

insert into client values('roule001','rouletabille claude','29, rue des lilas','Nancy','54000');