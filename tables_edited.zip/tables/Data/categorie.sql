
insert into categorie values('c1','citadine',4,'a1','t1');

insert into categorie values('c2','compacte',5,'a1','t2');

insert into categorie values('c3','familiale',5,'a1','t3');
